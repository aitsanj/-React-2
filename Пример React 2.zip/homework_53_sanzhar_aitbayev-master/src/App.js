import React, { useState } from 'react';
import './App.css';
import Card from './Card/card';
import CardDeck from './Card/carddeck'
import PockerHand from './Card/pockerHand';
function App() {
  const [cardsHand, setCard] = useState([{}]);
  const deck = new CardDeck();
  deck.getDeck();
  const addCards = ()=>{
  let cardsHandCopy = [...cardsHand];
  cardsHandCopy=deck.getCards();
  setCard(cardsHandCopy); 
};
const pocker = new PockerHand(cardsHand);
let combo = pocker.getOutcome();
let comboRender = (
  combo.map((card, index)=>{
    return <Card
    key = {index}
    rank = {card.rank}
    suit = {card.suit}
    />
  })
);
let cardRender = (  
      cardsHand.map((card,index)=>{
        return <Card
        key = {index}
        rank = {card.rank}
        suit = {card.suit}
        />
      }) 
);
  return (
    <div className="App">
      <button onClick={addCards}>Shuffle cards</button> 
      <div className="playingCards faceImages simpleCards rotateHand">         
        {cardRender} 
      </div> 
      <div className="playingCards faceImages simpleCards rotateHand">   
      <h1>Combo</h1>      
      {comboRender} 
      </div>  
    </div>
  );
}

export default App;
