import React from 'react';
import Card from './carddeck'
class PockerHand {
    constructor(cardsInHand){
        this.pockerHand = cardsInHand;
    };
    getOutcome = ()=>{
      let cardsInHandCopy = this.pockerHand;
        let arrCard = [];
        for (let i = 0; i<cardsInHandCopy.length;i++){
          let item = cardsInHandCopy[i];
          for (let j=0;j<cardsInHandCopy.length;j++){
            let itemArr = cardsInHandCopy[j];
            if (item.rank===itemArr.rank && item.suit!==itemArr.suit){
                arrCard.push(item);
            }
          };    
        };      
        let checkArr=[];
        let newArrFlesh = [];
        for (let i=0;i<cardsInHandCopy.length;i++){
          newArrFlesh.push(cardsInHandCopy[i].suit);
        }
        const obj = newArrFlesh.reduce((key,index)=>{
          return (typeof key[index]!=='undefined')? {...key, [index]: key[index]+1}:{...key,[index]:1}},{})
        console.log(obj)
        const fleshArr = Object.keys(obj).map((key)=> (obj[key]));
        console.log(fleshArr);
        if(fleshArr[0]===5){
          checkArr=cardsInHandCopy;
           alert("Флэш")
        };
        for (let c of arrCard){
          if(!checkArr.includes(c)){
            checkArr.push(c);
          }
        }  
        return checkArr;
      };
};
export default PockerHand;