import React from 'react';
import '../assets/cards.css';

const Card =props=> {
    const classNameCard = `card rank-${props.rank} ${props.suit}`
    const cardSuit = {
        diams: '♦',
        hearts:'♥',
        spades:'♠',
        clubs:'♣'
    };
    const suitOfCard = props.suit
    return (        
        <div className={classNameCard}>
            <span className="rank">{props.rank}</span>
            <span className="suit">{cardSuit[suitOfCard]}</span>
        </div>        
    )
};
export default Card;