class CardDeck {
    constructor(){
        this.suits = ['diams','hearts','spades', 'clubs'];
        this.ranks = [2,3,4,5,6,7,8,9,10,'j','q','k','a'];
        this.deck = [];
    }
    random(max,min){
        let randomIndex = Math.floor(Math.random()*(max-min)) +min;
        return randomIndex;
    }
    getDeck = ()=>{
        for (let i = 0;i<this.ranks.length;i++){
            for (let j=0;j<this.suits.length;j++){
                let cardInDeck = {
                    suit: this.suits[j],
                    rank:this.ranks[i]
                };
                this.deck.push(cardInDeck);
            };
        }  
        return this.deck;         
    }
    getCard = ()=>{
        let index = this.random(this.deck.length-1,0);
        let newCard = this.deck[index];
        this.deck.splice(index,1);
        return newCard;
    }
    getCards =howmany =>{
        howmany=5;
        const handsCard = [];
        for (let i=0;i<howmany;i++){
            handsCard.push(this.getCard());
        };
        return handsCard;
    }    
}
export default CardDeck;